package jaygoo.m3u8downloader;

/**
 * ================================================
 * 作    者：JayGoo
 * 版    本：
 * 创建日期：2017/11/21
 * 描    述:
 * ================================================
 */
public class VideoBean {
    public String url;
    public String state;
}
